/**
 * Created by JetBrains PhpStorm.
 * User: taoqili
 * Date: 12-2-10
 * Time: 下午3:50
 * To change this template use File | Settings | File Templates.
 */
//文件类型图标索引
var fileTypeMaps = {
    ".rar":"rar.gif",
    ".zip":"rar.gif",
    ".doc":"doc.gif",
    ".docx":"doc.gif",
    ".pdf":"pdf.gif",
    ".mp3":"mp3.gif",
    ".xls":"xls.gif",
    ".chm":"chm.gif",
    ".ppt":"ppt.gif",
    ".pptx":"ppt.gif",
    ".avi":"mv.gif",
    ".rmvb":"mv.gif",
    ".wmv":"mv.gif",
    ".flv":"mv.gif",
    ".swf":"mv.gif",
    ".rm":"mv.gif",
    ".exe":"exe.gif",
    ".psd":"psd.gif",
    ".txt":"txt.gif"
};