package com.xz.activiti.utils;
import org.apache.commons.lang.reflect.FieldUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;


import java.lang.reflect.Field;

/**
 * 实现对象的克隆功能
 */

public abstract class CloneUtils
{

    public static void copyFields(Object source, Object target, String... fieldNames)
    {
        Assert.assertNotNull(source);
        Assert.assertNotNull(target);
        Assert.assertSame(source.getClass(), target.getClass());

        for (String fieldName : fieldNames)
        {
            try
            {
                Field field = FieldUtils.getField(source.getClass(), fieldName, true);
                field.setAccessible(true);
                field.set(target, field.get(source));
            }
            catch (Exception e)
            {
                //TODO 
            }
        }
    }
}
