package com.xz.activiti.test;

import java.util.List;

import org.activiti.engine.identity.Group;
import org.activiti.engine.impl.persistence.entity.UserEntityManager;




public class UserTest {

	
}
