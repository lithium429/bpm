package com.xz.project.core.dao;

import com.xz.base.dao.BaseDao;
import com.xz.project.core.domain.entity.Department;

public interface DepartmentDao extends BaseDao<Department> {

}