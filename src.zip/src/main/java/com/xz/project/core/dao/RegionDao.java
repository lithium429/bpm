package com.xz.project.core.dao;

import com.xz.base.dao.BaseDao;
import com.xz.project.core.domain.entity.Region;

public interface RegionDao extends BaseDao<Region> {

}