package com.xz.project.core.dao;

import com.xz.base.dao.BaseDao;
import com.xz.project.core.domain.entity.SystemLog;

public interface SystemLogDao extends BaseDao<SystemLog> {

}