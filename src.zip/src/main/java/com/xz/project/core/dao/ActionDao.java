package com.xz.project.core.dao;

import com.xz.base.dao.BaseDao; 
import com.xz.project.core.domain.entity.Action;

public interface ActionDao extends BaseDao<Action> {

}