package com.xz.project.core.dao;

import com.xz.base.dao.BaseDao;
import com.xz.project.core.domain.entity.Menu;

public interface MenuDao extends BaseDao<Menu> {

}