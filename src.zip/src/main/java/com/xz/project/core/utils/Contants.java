/**   
* @Title: Contants.java 
* @Package: com.xz.project.core.utils 
* @Description: 
* @author: davidwan
* @date: 2014-12-29 上午10:21:54 
* @version: V1.0   
*/
package com.xz.project.core.utils;

public class Contants {
	/**
	* 会话id
	*/
	public static final String JSESSIONID = "JSESSIONID"; 
}
