package com.xz.project.core.dao;

import com.xz.base.dao.BaseDao;
import com.xz.project.core.domain.entity.Sms;

public interface SmsDao extends BaseDao<Sms> {

}