package com.xz.project.core.dao;

import java.util.List;

import com.xz.base.dao.BaseDao;
import com.xz.project.core.domain.entity.UserRole;

public interface UserRoleDao extends BaseDao<UserRole> {


}