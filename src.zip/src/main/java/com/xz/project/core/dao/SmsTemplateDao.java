package com.xz.project.core.dao;

import com.xz.base.dao.BaseDao;
import com.xz.project.core.domain.entity.SmsTemplate;

public interface SmsTemplateDao extends BaseDao<SmsTemplate> {

}